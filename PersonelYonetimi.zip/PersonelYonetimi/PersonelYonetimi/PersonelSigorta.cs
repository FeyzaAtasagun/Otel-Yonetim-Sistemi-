using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace PersonelYonetimi
{
    public partial class InsuranceForm : Form
    {
        // Form için gerekli değişkenler
        private int _personelId = 0;
        private bool _isNewRecord = true;

        public InsuranceForm()
        {
            InitializeComponent();
        }

        public InsuranceForm(int personelId)
        {
            InitializeComponent();
            _personelId = personelId;
            _isNewRecord = false;
            LoadInsuranceData();
        }

        private void InsuranceForm_Load(object sender, EventArgs e)
        {
            // Form yüklendiğinde çalışacak kod
            SetupDatePickers();
            if (!_isNewRecord)
            {
                this.Text = "Sigorta Bilgisi Güncelleme";
                btnSave.Text = "Güncelle";
                LoadInsuranceData();
            }
            else
            {
                this.Text = "Yeni Sigorta Bilgisi Ekle";
                btnSave.Text = "Kaydet";
            }
        }

        private void SetupDatePickers()
        {
            dtpBaslangicTarihi.Format = DateTimePickerFormat.Short;
            dtpBaslangicTarihi.Value = DateTime.Now;
            
            dtpBitisTarihi.Format = DateTimePickerFormat.Short;
            dtpBitisTarihi.Value = DateTime.Now.AddYears(1);
        }

        private void LoadInsuranceData()
        {
            try
            {
                // Veritabanından sigorta verilerini yükle
                // Bu kısım veritabanı bağlantınıza göre düzenlenmelidir
                using (SqlConnection conn = new SqlConnection("your_connection_string"))
                {
                    string query = "SELECT * FROM PersonelSigorta WHERE PersonelId = @PersonelId";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@PersonelId", _personelId);
                    
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    
                    if (reader.Read())
                    {
                        txtSigortaNo.Text = reader["SigortaNo"].ToString();
                        txtSigortaTuru.Text = reader["SigortaTuru"].ToString();
                        cmbSigortaFirmasi.Text = reader["SigortaFirmasi"].ToString();
                        dtpBaslangicTarihi.Value = Convert.ToDateTime(reader["BaslangicTarihi"]);
                        dtpBitisTarihi.Value = Convert.ToDateTime(reader["BitisTarihi"]);
                        numPrimTutari.Value = Convert.ToDecimal(reader["PrimTutari"]);
                        chkAktif.Checked = Convert.ToBoolean(reader["Aktif"]);
                        txtAciklama.Text = reader["Aciklama"].ToString();
                    }
                    
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yüklenirken hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                SaveInsuranceData();
            }
        }

        private bool ValidateForm()
        {
            // Form doğrulama kodları
            if (string.IsNullOrEmpty(txtSigortaNo.Text))
            {
                MessageBox.Show("Sigorta numarası boş olamaz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSigortaNo.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(txtSigortaTuru.Text))
            {
                MessageBox.Show("Sigorta türü boş olamaz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSigortaTuru.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(cmbSigortaFirmasi.Text))
            {
                MessageBox.Show("Sigorta firması seçilmelidir.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbSigortaFirmasi.Focus();
                return false;
            }

            if (dtpBitisTarihi.Value <= dtpBaslangicTarihi.Value)
            {
                MessageBox.Show("Bitiş tarihi başlangıç tarihinden sonra olmalıdır.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dtpBitisTarihi.Focus();
                return false;
            }

            return true;
        }

        private void SaveInsuranceData()
        {
            try
            {
                // Veritabanı kaydetme kodları
                using (SqlConnection conn = new SqlConnection("your_connection_string"))
                {
                    string query = _isNewRecord
                        ? "INSERT INTO PersonelSigorta (PersonelId, SigortaNo, SigortaTuru, SigortaFirmasi, BaslangicTarihi, BitisTarihi, PrimTutari, Aktif, Aciklama) " +
                          "VALUES (@PersonelId, @SigortaNo, @SigortaTuru, @SigortaFirmasi, @BaslangicTarihi, @BitisTarihi, @PrimTutari, @Aktif, @Aciklama)"
                        : "UPDATE PersonelSigorta SET SigortaNo = @SigortaNo, SigortaTuru = @SigortaTuru, SigortaFirmasi = @SigortaFirmasi, " +
                          "BaslangicTarihi = @BaslangicTarihi, BitisTarihi = @BitisTarihi, PrimTutari = @PrimTutari, Aktif = @Aktif, Aciklama = @Aciklama " +
                          "WHERE PersonelId = @PersonelId";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    
                    cmd.Parameters.AddWithValue("@PersonelId", _personelId);
                    cmd.Parameters.AddWithValue("@SigortaNo", txtSigortaNo.Text);
                    cmd.Parameters.AddWithValue("@SigortaTuru", txtSigortaTuru.Text);
                    cmd.Parameters.AddWithValue("@SigortaFirmasi", cmbSigortaFirmasi.Text);
                    cmd.Parameters.AddWithValue("@BaslangicTarihi", dtpBaslangicTarihi.Value);
                    cmd.Parameters.AddWithValue("@BitisTarihi", dtpBitisTarihi.Value);
                    cmd.Parameters.AddWithValue("@PrimTutari", numPrimTutari.Value);
                    cmd.Parameters.AddWithValue("@Aktif", chkAktif.Checked);
                    cmd.Parameters.AddWithValue("@Aciklama", txtAciklama.Text);
                    
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show(_isNewRecord ? "Sigorta bilgisi başarıyla eklendi." : "Sigorta bilgisi başarıyla güncellendi.", 
                    "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kayıt sırasında hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_isNewRecord)
            {
                MessageBox.Show("Henüz kaydedilmemiş bir kayıt silinemez.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bu sigorta kaydını silmek istediğinizden emin misiniz?", "Silme Onayı", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection("your_connection_string"))
                    {
                        string query = "DELETE FROM PersonelSigorta WHERE PersonelId = @PersonelId";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@PersonelId", _personelId);
                        
                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Sigorta bilgisi başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Silme sırasında hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void chkAktif_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
