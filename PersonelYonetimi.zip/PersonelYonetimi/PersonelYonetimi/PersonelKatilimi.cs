using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonelYonetimi
{
    public partial class PersonelKatilimFormu : Form
    {
        // Veritabanı bağlantısı buraya eklenecek
        
        public PersonelKatilimFormu()
        {
            InitializeComponent();
        }

        private void PersonelKatilimFormu_Load(object sender, EventArgs e)
        {
            // Form yüklendiğinde personel listesi doldurulur
            DoldurPersonelListesi();
            
            // DataGridView'i doldur
            KatilimVerileriniGetir();
            
            // Datetime picker için bugünün tarihini ayarla
            dateTimePickerTarih.Value = DateTime.Now;
        }

        private void DoldurPersonelListesi()
        {
            // Burada veritabanından personel listesi çekilecek
            // Örnek olarak bazı isimler ekliyorum
            comboBoxPersonel.Items.Add("Ahmet Yılmaz");
            comboBoxPersonel.Items.Add("Ayşe Demir");
            comboBoxPersonel.Items.Add("Mehmet Kaya");
            comboBoxPersonel.Items.Add("Zeynep Şahin");
        }

        private void KatilimVerileriniGetir()
        {
            // Burada veritabanından katılım verileri çekilecek
            // Örnek veri
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Personel", typeof(string));
            dt.Columns.Add("Tarih", typeof(DateTime));
            dt.Columns.Add("Geldi", typeof(bool));
            dt.Columns.Add("Gün Sayısı", typeof(int));
            dt.Columns.Add("Eksik Mesai (Saat)", typeof(decimal));
            dt.Columns.Add("Ek Mesai (Saat)", typeof(decimal));
            dt.Columns.Add("İzinli Gün", typeof(int));
            dt.Columns.Add("Açıklama", typeof(string));

            // Örnek veri ekleyelim
            dt.Rows.Add(1, "Ahmet Yılmaz", DateTime.Now.AddDays(-5), true, 1, 0, 2, 0, "Ek mesai yaptı");
            dt.Rows.Add(2, "Ayşe Demir", DateTime.Now.AddDays(-4), true, 1, 0, 0, 0, "");
            dt.Rows.Add(3, "Mehmet Kaya", DateTime.Now.AddDays(-3), false, 0, 0, 0, 1, "Yıllık izin");

            dataGridViewKatilim.DataSource = dt;
            dataGridViewKatilim.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (comboBoxPersonel.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen personel seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Verileri kaydet
            string personel = comboBoxPersonel.SelectedItem.ToString();
            DateTime tarih = dateTimePickerTarih.Value;
            bool geldi = checkBoxGeldi.Checked;
            int gunSayisi = geldi ? Convert.ToInt32(numericGunSayisi.Value) : 0;
            decimal eksikMesai = Convert.ToDecimal(numericEksikMesai.Value);
            decimal ekMesai = Convert.ToDecimal(numericEkMesai.Value);
            int izinliGun = Convert.ToInt32(numericIzinliGun.Value);
            string aciklama = textBoxAciklama.Text;

            // Burada veritabanına kayıt işlemi yapılacak
            MessageBox.Show("Kayıt başarıyla eklendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Formu temizle
            FormuTemizle();
            
            // Tabloyu güncelle
            KatilimVerileriniGetir();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (dataGridViewKatilim.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen güncellemek için bir kayıt seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Seçili satırdan verileri al
            int id = Convert.ToInt32(dataGridViewKatilim.SelectedRows[0].Cells["ID"].Value);
            
            // Burada veritabanı güncelleme işlemi yapılacak
            MessageBox.Show("Kayıt başarıyla güncellendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            // Tabloyu güncelle
            KatilimVerileriniGetir();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dataGridViewKatilim.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen silmek için bir kayıt seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kullanıcıya onay sor
            DialogResult result = MessageBox.Show("Seçili kaydı silmek istediğinize emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            if (result == DialogResult.Yes)
            {
                // Seçili satırdan ID'yi al
                int id = Convert.ToInt32(dataGridViewKatilim.SelectedRows[0].Cells["ID"].Value);
                
                // Burada veritabanı silme işlemi yapılacak
                MessageBox.Show("Kayıt başarıyla silindi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                // Tabloyu güncelle
                KatilimVerileriniGetir();
            }
        }

        private void btnYeni_Click(object sender, EventArgs e)
        {
            FormuTemizle();
        }

        private void FormuTemizle()
        {
            comboBoxPersonel.SelectedIndex = -1;
            dateTimePickerTarih.Value = DateTime.Now;
            checkBoxGeldi.Checked = true;
            numericGunSayisi.Value = 1;
            numericEksikMesai.Value = 0;
            numericEkMesai.Value = 0;
            numericIzinliGun.Value = 0;
            textBoxAciklama.Text = "";
        }

        private void dataGridViewKatilim_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Seçili satırdan verileri al ve formu doldur
                DataGridViewRow row = dataGridViewKatilim.Rows[e.RowIndex];
                
                comboBoxPersonel.Text = row.Cells["Personel"].Value.ToString();
                dateTimePickerTarih.Value = Convert.ToDateTime(row.Cells["Tarih"].Value);
                checkBoxGeldi.Checked = Convert.ToBoolean(row.Cells["Geldi"].Value);
                numericGunSayisi.Value = Convert.ToDecimal(row.Cells["Gün Sayısı"].Value);
                numericEksikMesai.Value = Convert.ToDecimal(row.Cells["Eksik Mesai (Saat)"].Value);
                numericEkMesai.Value = Convert.ToDecimal(row.Cells["Ek Mesai (Saat)"].Value);
                numericIzinliGun.Value = Convert.ToDecimal(row.Cells["İzinli Gün"].Value);
                textBoxAciklama.Text = row.Cells["Açıklama"].Value.ToString();
            }
        }

        private void checkBoxGeldi_CheckedChanged(object sender, EventArgs e)
        {
            numericGunSayisi.Enabled = checkBoxGeldi.Checked;
            numericEksikMesai.Enabled = checkBoxGeldi.Checked;
            numericEkMesai.Enabled = checkBoxGeldi.Checked;
            
            if (!checkBoxGeldi.Checked)
            {
                numericGunSayisi.Value = 0;
                numericEksikMesai.Value = 0;
                numericEkMesai.Value = 0;
            }
            else
            {
                numericGunSayisi.Value = 1;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
