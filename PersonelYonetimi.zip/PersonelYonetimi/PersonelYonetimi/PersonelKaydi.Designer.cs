﻿namespace PersonelYonetimi
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.eklePerAktiflik = new System.Windows.Forms.ComboBox();
            this.perAktiflik = new System.Windows.Forms.Label();
            this.btnPerYukle = new System.Windows.Forms.Button();
            this.eklePerPozisyon = new System.Windows.Forms.ComboBox();
            this.perPozisyon = new System.Windows.Forms.Label();
            this.txtPerTC = new System.Windows.Forms.TextBox();
            this.perTC = new System.Windows.Forms.Label();
            this.eklePerCinsiyet = new System.Windows.Forms.ComboBox();
            this.perCinsiyet = new System.Windows.Forms.Label();
            this.txtPerAd = new System.Windows.Forms.TextBox();
            this.perAd = new System.Windows.Forms.Label();
            this.txtPersonel_id = new System.Windows.Forms.TextBox();
            this.perID = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.personelIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tCKimlikNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soyadiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dogumTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cinsiyetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pozisyonIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aktifMiDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.personelBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.otelPersonelYonetimiDataSet = new PersonelYonetimi.OtelPersonelYonetimiDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.otelPersonelYonetimiDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPerTemizle = new System.Windows.Forms.Button();
            this.eklePerBasTarih = new System.Windows.Forms.DateTimePicker();
            this.perBaslama = new System.Windows.Forms.Label();
            this.eklePerAyrTarih = new System.Windows.Forms.DateTimePicker();
            this.perAyrilma = new System.Windows.Forms.Label();
            this.txtPerEmail = new System.Windows.Forms.TextBox();
            this.perMail = new System.Windows.Forms.Label();
            this.eklePerAdres = new System.Windows.Forms.TextBox();
            this.perAdres = new System.Windows.Forms.Label();
            this.txtPerSoyad = new System.Windows.Forms.TextBox();
            this.perSoyad = new System.Windows.Forms.Label();
            this.eklePerDTarih = new System.Windows.Forms.DateTimePicker();
            this.perDTarih = new System.Windows.Forms.Label();
            this.txtPerTel = new System.Windows.Forms.TextBox();
            this.perTel = new System.Windows.Forms.Label();
            this.personelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.personelTableAdapter = new PersonelYonetimi.OtelPersonelYonetimiDataSetTableAdapters.PersonelTableAdapter();
            this.personelBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.btnPerAra = new System.Windows.Forms.Button();
            this.btnPerSil = new System.Windows.Forms.Button();
            this.btnPerGuncelle = new System.Windows.Forms.Button();
            this.btnPerEkle = new System.Windows.Forms.Button();
            this.eklePerResim = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.perDepartman = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personelBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelPersonelYonetimiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelPersonelYonetimiDataSetBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.personelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personelBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eklePerResim)).BeginInit();
            this.SuspendLayout();
            // 
            // eklePerAktiflik
            // 
            this.eklePerAktiflik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eklePerAktiflik.FormattingEnabled = true;
            this.eklePerAktiflik.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.eklePerAktiflik.Location = new System.Drawing.Point(277, 240);
            this.eklePerAktiflik.Name = "eklePerAktiflik";
            this.eklePerAktiflik.Size = new System.Drawing.Size(195, 26);
            this.eklePerAktiflik.TabIndex = 18;
            // 
            // perAktiflik
            // 
            this.perAktiflik.AutoSize = true;
            this.perAktiflik.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perAktiflik.Location = new System.Drawing.Point(211, 244);
            this.perAktiflik.Name = "perAktiflik";
            this.perAktiflik.Size = new System.Drawing.Size(57, 18);
            this.perAktiflik.TabIndex = 17;
            this.perAktiflik.Text = "Durum:";
            // 
            // btnPerYukle
            // 
            this.btnPerYukle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnPerYukle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerYukle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerYukle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerYukle.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerYukle.ForeColor = System.Drawing.Color.White;
            this.btnPerYukle.Location = new System.Drawing.Point(34, 170);
            this.btnPerYukle.Name = "btnPerYukle";
            this.btnPerYukle.Size = new System.Drawing.Size(112, 33);
            this.btnPerYukle.TabIndex = 12;
            this.btnPerYukle.Text = "Resim Yükle";
            this.btnPerYukle.UseVisualStyleBackColor = false;
            // 
            // eklePerPozisyon
            // 
            this.eklePerPozisyon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eklePerPozisyon.FormattingEnabled = true;
            this.eklePerPozisyon.Items.AddRange(new object[] {
            "Bussiness Manager",
            "Front-End Developer ",
            ".NET Developer ",
            "Back-End Developer ",
            "Data Administrator ",
            "DevOps ",
            "Software Engineer - JAVA",
            "QA ",
            "UI/UX Designer "});
            this.eklePerPozisyon.Location = new System.Drawing.Point(277, 198);
            this.eklePerPozisyon.Name = "eklePerPozisyon";
            this.eklePerPozisyon.Size = new System.Drawing.Size(195, 26);
            this.eklePerPozisyon.TabIndex = 10;
            // 
            // perPozisyon
            // 
            this.perPozisyon.AutoSize = true;
            this.perPozisyon.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perPozisyon.Location = new System.Drawing.Point(206, 203);
            this.perPozisyon.Name = "perPozisyon";
            this.perPozisyon.Size = new System.Drawing.Size(69, 18);
            this.perPozisyon.TabIndex = 9;
            this.perPozisyon.Text = "Pozisyon:";
            // 
            // txtPerTC
            // 
            this.txtPerTC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerTC.Location = new System.Drawing.Point(632, 160);
            this.txtPerTC.Multiline = true;
            this.txtPerTC.Name = "txtPerTC";
            this.txtPerTC.Size = new System.Drawing.Size(179, 25);
            this.txtPerTC.TabIndex = 8;
            // 
            // perTC
            // 
            this.perTC.AutoSize = true;
            this.perTC.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perTC.Location = new System.Drawing.Point(531, 162);
            this.perTC.Name = "perTC";
            this.perTC.Size = new System.Drawing.Size(95, 18);
            this.perTC.TabIndex = 7;
            this.perTC.Text = "TC Kimlik No:";
            // 
            // eklePerCinsiyet
            // 
            this.eklePerCinsiyet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eklePerCinsiyet.FormattingEnabled = true;
            this.eklePerCinsiyet.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.eklePerCinsiyet.Location = new System.Drawing.Point(277, 114);
            this.eklePerCinsiyet.Name = "eklePerCinsiyet";
            this.eklePerCinsiyet.Size = new System.Drawing.Size(195, 26);
            this.eklePerCinsiyet.TabIndex = 6;
            // 
            // perCinsiyet
            // 
            this.perCinsiyet.AutoSize = true;
            this.perCinsiyet.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perCinsiyet.Location = new System.Drawing.Point(211, 118);
            this.perCinsiyet.Name = "perCinsiyet";
            this.perCinsiyet.Size = new System.Drawing.Size(62, 18);
            this.perCinsiyet.TabIndex = 5;
            this.perCinsiyet.Text = "Cinsiyet:";
            // 
            // txtPerAd
            // 
            this.txtPerAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerAd.Location = new System.Drawing.Point(277, 66);
            this.txtPerAd.Multiline = true;
            this.txtPerAd.Name = "txtPerAd";
            this.txtPerAd.Size = new System.Drawing.Size(195, 23);
            this.txtPerAd.TabIndex = 4;
            // 
            // perAd
            // 
            this.perAd.AutoSize = true;
            this.perAd.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perAd.Location = new System.Drawing.Point(226, 69);
            this.perAd.Name = "perAd";
            this.perAd.Size = new System.Drawing.Size(37, 18);
            this.perAd.TabIndex = 3;
            this.perAd.Text = "Adı :";
            // 
            // txtPersonel_id
            // 
            this.txtPersonel_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPersonel_id.Location = new System.Drawing.Point(277, 20);
            this.txtPersonel_id.Multiline = true;
            this.txtPersonel_id.Name = "txtPersonel_id";
            this.txtPersonel_id.Size = new System.Drawing.Size(195, 23);
            this.txtPersonel_id.TabIndex = 2;
            // 
            // perID
            // 
            this.perID.AutoSize = true;
            this.perID.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perID.Location = new System.Drawing.Point(174, 22);
            this.perID.Name = "perID";
            this.perID.Size = new System.Drawing.Size(88, 18);
            this.perID.TabIndex = 1;
            this.perID.Text = "Personel ID:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 462);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(881, 357);
            this.panel1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(11)))), ((int)(((byte)(97)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.personelIDDataGridViewTextBoxColumn,
            this.tCKimlikNoDataGridViewTextBoxColumn,
            this.adiDataGridViewTextBoxColumn,
            this.soyadiDataGridViewTextBoxColumn,
            this.dogumTarihiDataGridViewTextBoxColumn,
            this.cinsiyetDataGridViewTextBoxColumn,
            this.adresDataGridViewTextBoxColumn,
            this.telefonDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn,
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn,
            this.pozisyonIDDataGridViewTextBoxColumn,
            this.aktifMiDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.personelBindingSource2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(11)))), ((int)(((byte)(97)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(879, 355);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // personelIDDataGridViewTextBoxColumn
            // 
            this.personelIDDataGridViewTextBoxColumn.DataPropertyName = "PersonelID";
            this.personelIDDataGridViewTextBoxColumn.HeaderText = "PersonelID";
            this.personelIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.personelIDDataGridViewTextBoxColumn.Name = "personelIDDataGridViewTextBoxColumn";
            this.personelIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.personelIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // tCKimlikNoDataGridViewTextBoxColumn
            // 
            this.tCKimlikNoDataGridViewTextBoxColumn.DataPropertyName = "TCKimlikNo";
            this.tCKimlikNoDataGridViewTextBoxColumn.HeaderText = "TCKimlikNo";
            this.tCKimlikNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tCKimlikNoDataGridViewTextBoxColumn.Name = "tCKimlikNoDataGridViewTextBoxColumn";
            this.tCKimlikNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.tCKimlikNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // adiDataGridViewTextBoxColumn
            // 
            this.adiDataGridViewTextBoxColumn.DataPropertyName = "Adi";
            this.adiDataGridViewTextBoxColumn.HeaderText = "Adi";
            this.adiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.adiDataGridViewTextBoxColumn.Name = "adiDataGridViewTextBoxColumn";
            this.adiDataGridViewTextBoxColumn.ReadOnly = true;
            this.adiDataGridViewTextBoxColumn.Width = 125;
            // 
            // soyadiDataGridViewTextBoxColumn
            // 
            this.soyadiDataGridViewTextBoxColumn.DataPropertyName = "Soyadi";
            this.soyadiDataGridViewTextBoxColumn.HeaderText = "Soyadi";
            this.soyadiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.soyadiDataGridViewTextBoxColumn.Name = "soyadiDataGridViewTextBoxColumn";
            this.soyadiDataGridViewTextBoxColumn.ReadOnly = true;
            this.soyadiDataGridViewTextBoxColumn.Width = 125;
            // 
            // dogumTarihiDataGridViewTextBoxColumn
            // 
            this.dogumTarihiDataGridViewTextBoxColumn.DataPropertyName = "DogumTarihi";
            this.dogumTarihiDataGridViewTextBoxColumn.HeaderText = "DogumTarihi";
            this.dogumTarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dogumTarihiDataGridViewTextBoxColumn.Name = "dogumTarihiDataGridViewTextBoxColumn";
            this.dogumTarihiDataGridViewTextBoxColumn.ReadOnly = true;
            this.dogumTarihiDataGridViewTextBoxColumn.Width = 125;
            // 
            // cinsiyetDataGridViewTextBoxColumn
            // 
            this.cinsiyetDataGridViewTextBoxColumn.DataPropertyName = "Cinsiyet";
            this.cinsiyetDataGridViewTextBoxColumn.HeaderText = "Cinsiyet";
            this.cinsiyetDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cinsiyetDataGridViewTextBoxColumn.Name = "cinsiyetDataGridViewTextBoxColumn";
            this.cinsiyetDataGridViewTextBoxColumn.ReadOnly = true;
            this.cinsiyetDataGridViewTextBoxColumn.Width = 125;
            // 
            // adresDataGridViewTextBoxColumn
            // 
            this.adresDataGridViewTextBoxColumn.DataPropertyName = "Adres";
            this.adresDataGridViewTextBoxColumn.HeaderText = "Adres";
            this.adresDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.adresDataGridViewTextBoxColumn.Name = "adresDataGridViewTextBoxColumn";
            this.adresDataGridViewTextBoxColumn.ReadOnly = true;
            this.adresDataGridViewTextBoxColumn.Width = 125;
            // 
            // telefonDataGridViewTextBoxColumn
            // 
            this.telefonDataGridViewTextBoxColumn.DataPropertyName = "Telefon";
            this.telefonDataGridViewTextBoxColumn.HeaderText = "Telefon";
            this.telefonDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.telefonDataGridViewTextBoxColumn.Name = "telefonDataGridViewTextBoxColumn";
            this.telefonDataGridViewTextBoxColumn.ReadOnly = true;
            this.telefonDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.ReadOnly = true;
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // ıseBaslamaTarihiDataGridViewTextBoxColumn
            // 
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn.DataPropertyName = "IseBaslamaTarihi";
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn.HeaderText = "IseBaslamaTarihi";
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn.Name = "ıseBaslamaTarihiDataGridViewTextBoxColumn";
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn.ReadOnly = true;
            this.ıseBaslamaTarihiDataGridViewTextBoxColumn.Width = 125;
            // 
            // ıstenAyrilmaTarihiDataGridViewTextBoxColumn
            // 
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn.DataPropertyName = "IstenAyrilmaTarihi";
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn.HeaderText = "IstenAyrilmaTarihi";
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn.Name = "ıstenAyrilmaTarihiDataGridViewTextBoxColumn";
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn.ReadOnly = true;
            this.ıstenAyrilmaTarihiDataGridViewTextBoxColumn.Width = 125;
            // 
            // pozisyonIDDataGridViewTextBoxColumn
            // 
            this.pozisyonIDDataGridViewTextBoxColumn.DataPropertyName = "PozisyonID";
            this.pozisyonIDDataGridViewTextBoxColumn.HeaderText = "PozisyonID";
            this.pozisyonIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pozisyonIDDataGridViewTextBoxColumn.Name = "pozisyonIDDataGridViewTextBoxColumn";
            this.pozisyonIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.pozisyonIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aktifMiDataGridViewCheckBoxColumn
            // 
            this.aktifMiDataGridViewCheckBoxColumn.DataPropertyName = "AktifMi";
            this.aktifMiDataGridViewCheckBoxColumn.HeaderText = "AktifMi";
            this.aktifMiDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.aktifMiDataGridViewCheckBoxColumn.Name = "aktifMiDataGridViewCheckBoxColumn";
            this.aktifMiDataGridViewCheckBoxColumn.ReadOnly = true;
            this.aktifMiDataGridViewCheckBoxColumn.Width = 125;
            // 
            // personelBindingSource2
            // 
            this.personelBindingSource2.DataMember = "Personel";
            this.personelBindingSource2.DataSource = this.otelPersonelYonetimiDataSet;
            // 
            // otelPersonelYonetimiDataSet
            // 
            this.otelPersonelYonetimiDataSet.DataSetName = "OtelPersonelYonetimiDataSet";
            this.otelPersonelYonetimiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Impact", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(350, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Personel Bilgileri";
            // 
            // otelPersonelYonetimiDataSetBindingSource
            // 
            this.otelPersonelYonetimiDataSetBindingSource.DataSource = this.otelPersonelYonetimiDataSet;
            this.otelPersonelYonetimiDataSetBindingSource.Position = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.perDepartman);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btnPerAra);
            this.panel2.Controls.Add(this.btnPerTemizle);
            this.panel2.Controls.Add(this.eklePerBasTarih);
            this.panel2.Controls.Add(this.perBaslama);
            this.panel2.Controls.Add(this.eklePerAyrTarih);
            this.panel2.Controls.Add(this.perAyrilma);
            this.panel2.Controls.Add(this.txtPerEmail);
            this.panel2.Controls.Add(this.perMail);
            this.panel2.Controls.Add(this.eklePerAdres);
            this.panel2.Controls.Add(this.perAdres);
            this.panel2.Controls.Add(this.txtPerSoyad);
            this.panel2.Controls.Add(this.perSoyad);
            this.panel2.Controls.Add(this.eklePerDTarih);
            this.panel2.Controls.Add(this.perDTarih);
            this.panel2.Controls.Add(this.txtPerTel);
            this.panel2.Controls.Add(this.perTel);
            this.panel2.Controls.Add(this.eklePerAktiflik);
            this.panel2.Controls.Add(this.perAktiflik);
            this.panel2.Controls.Add(this.btnPerSil);
            this.panel2.Controls.Add(this.btnPerGuncelle);
            this.panel2.Controls.Add(this.btnPerEkle);
            this.panel2.Controls.Add(this.btnPerYukle);
            this.panel2.Controls.Add(this.eklePerResim);
            this.panel2.Controls.Add(this.eklePerPozisyon);
            this.panel2.Controls.Add(this.perPozisyon);
            this.panel2.Controls.Add(this.txtPerTC);
            this.panel2.Controls.Add(this.perTC);
            this.panel2.Controls.Add(this.eklePerCinsiyet);
            this.panel2.Controls.Add(this.perCinsiyet);
            this.panel2.Controls.Add(this.txtPerAd);
            this.panel2.Controls.Add(this.perAd);
            this.panel2.Controls.Add(this.txtPersonel_id);
            this.panel2.Controls.Add(this.perID);
            this.panel2.Location = new System.Drawing.Point(12, 11);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(881, 466);
            this.panel2.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Location = new System.Drawing.Point(537, 370);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 16);
            this.label5.TabIndex = 38;
            this.label5.Text = "Kaydı Sil";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(359, 370);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 16);
            this.label4.TabIndex = 37;
            this.label4.Text = "Kaydı Düzenle";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(204, 370);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 36;
            this.label3.Text = "Kayıt Ekle";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(45, 370);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 16);
            this.label2.TabIndex = 35;
            this.label2.Text = "Kayıt Bul";
            // 
            // btnPerTemizle
            // 
            this.btnPerTemizle.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnPerTemizle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerTemizle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerTemizle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerTemizle.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerTemizle.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnPerTemizle.Location = new System.Drawing.Point(658, 386);
            this.btnPerTemizle.Name = "btnPerTemizle";
            this.btnPerTemizle.Size = new System.Drawing.Size(154, 45);
            this.btnPerTemizle.TabIndex = 33;
            this.btnPerTemizle.Text = "Bilgileri Temizle";
            this.btnPerTemizle.UseVisualStyleBackColor = false;
            // 
            // eklePerBasTarih
            // 
            this.eklePerBasTarih.Location = new System.Drawing.Point(656, 263);
            this.eklePerBasTarih.Name = "eklePerBasTarih";
            this.eklePerBasTarih.Size = new System.Drawing.Size(155, 22);
            this.eklePerBasTarih.TabIndex = 32;
            // 
            // perBaslama
            // 
            this.perBaslama.AutoSize = true;
            this.perBaslama.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perBaslama.Location = new System.Drawing.Point(501, 266);
            this.perBaslama.Name = "perBaslama";
            this.perBaslama.Size = new System.Drawing.Size(134, 18);
            this.perBaslama.TabIndex = 31;
            this.perBaslama.Text = "İşe Başlama Tarihi:";
            // 
            // eklePerAyrTarih
            // 
            this.eklePerAyrTarih.Location = new System.Drawing.Point(655, 308);
            this.eklePerAyrTarih.Name = "eklePerAyrTarih";
            this.eklePerAyrTarih.Size = new System.Drawing.Size(156, 22);
            this.eklePerAyrTarih.TabIndex = 30;
            // 
            // perAyrilma
            // 
            this.perAyrilma.AutoSize = true;
            this.perAyrilma.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perAyrilma.Location = new System.Drawing.Point(496, 310);
            this.perAyrilma.Name = "perAyrilma";
            this.perAyrilma.Size = new System.Drawing.Size(139, 18);
            this.perAyrilma.TabIndex = 29;
            this.perAyrilma.Text = "İşten Ayrılma Tarihi:";
            // 
            // txtPerEmail
            // 
            this.txtPerEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerEmail.Location = new System.Drawing.Point(632, 20);
            this.txtPerEmail.Multiline = true;
            this.txtPerEmail.Name = "txtPerEmail";
            this.txtPerEmail.Size = new System.Drawing.Size(179, 23);
            this.txtPerEmail.TabIndex = 28;
            // 
            // perMail
            // 
            this.perMail.AutoSize = true;
            this.perMail.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perMail.Location = new System.Drawing.Point(572, 23);
            this.perMail.Name = "perMail";
            this.perMail.Size = new System.Drawing.Size(46, 18);
            this.perMail.TabIndex = 27;
            this.perMail.Text = "Email:";
            // 
            // eklePerAdres
            // 
            this.eklePerAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eklePerAdres.Location = new System.Drawing.Point(277, 292);
            this.eklePerAdres.Multiline = true;
            this.eklePerAdres.Name = "eklePerAdres";
            this.eklePerAdres.Size = new System.Drawing.Size(195, 53);
            this.eklePerAdres.TabIndex = 26;
            // 
            // perAdres
            // 
            this.perAdres.AutoSize = true;
            this.perAdres.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perAdres.Location = new System.Drawing.Point(218, 295);
            this.perAdres.Name = "perAdres";
            this.perAdres.Size = new System.Drawing.Size(50, 18);
            this.perAdres.TabIndex = 25;
            this.perAdres.Text = "Adres:";
            // 
            // txtPerSoyad
            // 
            this.txtPerSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerSoyad.Location = new System.Drawing.Point(632, 66);
            this.txtPerSoyad.Multiline = true;
            this.txtPerSoyad.Name = "txtPerSoyad";
            this.txtPerSoyad.Size = new System.Drawing.Size(179, 23);
            this.txtPerSoyad.TabIndex = 24;
            // 
            // perSoyad
            // 
            this.perSoyad.AutoSize = true;
            this.perSoyad.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perSoyad.Location = new System.Drawing.Point(564, 69);
            this.perSoyad.Name = "perSoyad";
            this.perSoyad.Size = new System.Drawing.Size(55, 18);
            this.perSoyad.TabIndex = 23;
            this.perSoyad.Text = "Soyadı:";
            // 
            // eklePerDTarih
            // 
            this.eklePerDTarih.Location = new System.Drawing.Point(656, 209);
            this.eklePerDTarih.Name = "eklePerDTarih";
            this.eklePerDTarih.Size = new System.Drawing.Size(155, 22);
            this.eklePerDTarih.TabIndex = 22;
            // 
            // perDTarih
            // 
            this.perDTarih.AutoSize = true;
            this.perDTarih.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perDTarih.Location = new System.Drawing.Point(539, 211);
            this.perDTarih.Name = "perDTarih";
            this.perDTarih.Size = new System.Drawing.Size(100, 18);
            this.perDTarih.TabIndex = 21;
            this.perDTarih.Text = "Doğum Tarihi:";
            // 
            // txtPerTel
            // 
            this.txtPerTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPerTel.Location = new System.Drawing.Point(632, 112);
            this.txtPerTel.Multiline = true;
            this.txtPerTel.Name = "txtPerTel";
            this.txtPerTel.Size = new System.Drawing.Size(179, 25);
            this.txtPerTel.TabIndex = 20;
            // 
            // perTel
            // 
            this.perTel.AutoSize = true;
            this.perTel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perTel.Location = new System.Drawing.Point(505, 115);
            this.perTel.Name = "perTel";
            this.perTel.Size = new System.Drawing.Size(128, 18);
            this.perTel.TabIndex = 19;
            this.perTel.Text = "Telefon Numarası:";
            // 
            // personelBindingSource
            // 
            this.personelBindingSource.DataMember = "Personel";
            this.personelBindingSource.DataSource = this.otelPersonelYonetimiDataSetBindingSource;
            // 
            // personelTableAdapter
            // 
            this.personelTableAdapter.ClearBeforeFill = true;
            // 
            // personelBindingSource1
            // 
            this.personelBindingSource1.DataMember = "Personel";
            this.personelBindingSource1.DataSource = this.otelPersonelYonetimiDataSetBindingSource;
            // 
            // btnPerAra
            // 
            this.btnPerAra.BackColor = System.Drawing.Color.DarkViolet;
            this.btnPerAra.BackgroundImage = global::PersonelYonetimi.Properties.Resources._46833_search_user_icon;
            this.btnPerAra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPerAra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerAra.FlatAppearance.BorderSize = 0;
            this.btnPerAra.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(11)))), ((int)(((byte)(97)))));
            this.btnPerAra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerAra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerAra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPerAra.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerAra.ForeColor = System.Drawing.Color.White;
            this.btnPerAra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPerAra.Location = new System.Drawing.Point(14, 386);
            this.btnPerAra.Name = "btnPerAra";
            this.btnPerAra.Size = new System.Drawing.Size(124, 43);
            this.btnPerAra.TabIndex = 34;
            this.btnPerAra.UseVisualStyleBackColor = false;
            this.btnPerAra.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPerSil
            // 
            this.btnPerSil.BackColor = System.Drawing.Color.DarkViolet;
            this.btnPerSil.BackgroundImage = global::PersonelYonetimi.Properties.Resources._46794_delete_user_icon;
            this.btnPerSil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPerSil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerSil.FlatAppearance.BorderSize = 0;
            this.btnPerSil.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(11)))), ((int)(((byte)(97)))));
            this.btnPerSil.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerSil.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPerSil.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerSil.ForeColor = System.Drawing.Color.White;
            this.btnPerSil.Location = new System.Drawing.Point(508, 386);
            this.btnPerSil.Name = "btnPerSil";
            this.btnPerSil.Size = new System.Drawing.Size(118, 43);
            this.btnPerSil.TabIndex = 15;
            this.btnPerSil.UseVisualStyleBackColor = false;
            // 
            // btnPerGuncelle
            // 
            this.btnPerGuncelle.BackColor = System.Drawing.Color.DarkViolet;
            this.btnPerGuncelle.BackgroundImage = global::PersonelYonetimi.Properties.Resources._46799_edit_user_icon;
            this.btnPerGuncelle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPerGuncelle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerGuncelle.FlatAppearance.BorderSize = 0;
            this.btnPerGuncelle.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(11)))), ((int)(((byte)(97)))));
            this.btnPerGuncelle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerGuncelle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerGuncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPerGuncelle.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerGuncelle.ForeColor = System.Drawing.Color.White;
            this.btnPerGuncelle.Location = new System.Drawing.Point(341, 386);
            this.btnPerGuncelle.Name = "btnPerGuncelle";
            this.btnPerGuncelle.Size = new System.Drawing.Size(130, 43);
            this.btnPerGuncelle.TabIndex = 14;
            this.btnPerGuncelle.UseVisualStyleBackColor = false;
            // 
            // btnPerEkle
            // 
            this.btnPerEkle.BackColor = System.Drawing.Color.DarkViolet;
            this.btnPerEkle.BackgroundImage = global::PersonelYonetimi.Properties.Resources._46775_add_user_icon;
            this.btnPerEkle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnPerEkle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerEkle.FlatAppearance.BorderSize = 0;
            this.btnPerEkle.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(11)))), ((int)(((byte)(97)))));
            this.btnPerEkle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerEkle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(8)))), ((int)(((byte)(138)))));
            this.btnPerEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPerEkle.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPerEkle.ForeColor = System.Drawing.Color.White;
            this.btnPerEkle.Location = new System.Drawing.Point(173, 386);
            this.btnPerEkle.Name = "btnPerEkle";
            this.btnPerEkle.Size = new System.Drawing.Size(130, 45);
            this.btnPerEkle.TabIndex = 13;
            this.btnPerEkle.UseVisualStyleBackColor = false;
            this.btnPerEkle.Click += new System.EventHandler(this.btnPerEkle_Click);
            // 
            // eklePerResim
            // 
            this.eklePerResim.BackColor = System.Drawing.SystemColors.HighlightText;
            this.eklePerResim.BackgroundImage = global::PersonelYonetimi.Properties.Resources.user;
            this.eklePerResim.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.eklePerResim.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.eklePerResim.ErrorImage = null;
            this.eklePerResim.Location = new System.Drawing.Point(27, 16);
            this.eklePerResim.Name = "eklePerResim";
            this.eklePerResim.Size = new System.Drawing.Size(134, 133);
            this.eklePerResim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.eklePerResim.TabIndex = 11;
            this.eklePerResim.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Bussiness Manager",
            "Front-End Developer ",
            ".NET Developer ",
            "Back-End Developer ",
            "Data Administrator ",
            "DevOps ",
            "Software Engineer - JAVA",
            "QA ",
            "UI/UX Designer "});
            this.comboBox1.Location = new System.Drawing.Point(277, 154);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(195, 26);
            this.comboBox1.TabIndex = 40;
            // 
            // perDepartman
            // 
            this.perDepartman.AutoSize = true;
            this.perDepartman.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perDepartman.Location = new System.Drawing.Point(193, 158);
            this.perDepartman.Name = "perDepartman";
            this.perDepartman.Size = new System.Drawing.Size(86, 18);
            this.perDepartman.TabIndex = 39;
            this.perDepartman.Text = "Departman:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 831);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personelBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelPersonelYonetimiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otelPersonelYonetimiDataSetBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.personelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personelBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eklePerResim)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox eklePerAktiflik;
        private System.Windows.Forms.Label perAktiflik;
        private System.Windows.Forms.Button btnPerSil;
        private System.Windows.Forms.Button btnPerGuncelle;
        private System.Windows.Forms.Button btnPerEkle;
        private System.Windows.Forms.Button btnPerYukle;
        private System.Windows.Forms.PictureBox eklePerResim;
        private System.Windows.Forms.ComboBox eklePerPozisyon;
        private System.Windows.Forms.Label perPozisyon;
        private System.Windows.Forms.TextBox txtPerTC;
        private System.Windows.Forms.Label perTC;
        private System.Windows.Forms.ComboBox eklePerCinsiyet;
        private System.Windows.Forms.Label perCinsiyet;
        private System.Windows.Forms.TextBox txtPerAd;
        private System.Windows.Forms.Label perAd;
        private System.Windows.Forms.TextBox txtPersonel_id;
        private System.Windows.Forms.Label perID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtPerTel;
        private System.Windows.Forms.Label perTel;
        private System.Windows.Forms.TextBox txtPerSoyad;
        private System.Windows.Forms.Label perSoyad;
        private System.Windows.Forms.DateTimePicker eklePerDTarih;
        private System.Windows.Forms.DateTimePicker eklePerBasTarih;
        private System.Windows.Forms.Label perBaslama;
        private System.Windows.Forms.DateTimePicker eklePerAyrTarih;
        private System.Windows.Forms.Label perAyrilma;
        private System.Windows.Forms.TextBox txtPerEmail;
        private System.Windows.Forms.Label perMail;
        private System.Windows.Forms.TextBox eklePerAdres;
        private System.Windows.Forms.Label perAdres;
        private System.Windows.Forms.Label perDTarih;
        private System.Windows.Forms.Button btnPerTemizle;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnPerAra;
        private System.Windows.Forms.BindingSource otelPersonelYonetimiDataSetBindingSource;
        private OtelPersonelYonetimiDataSet otelPersonelYonetimiDataSet;
        private System.Windows.Forms.BindingSource personelBindingSource;
        private OtelPersonelYonetimiDataSetTableAdapters.PersonelTableAdapter personelTableAdapter;
        private System.Windows.Forms.BindingSource personelBindingSource2;
        private System.Windows.Forms.BindingSource personelBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn personelIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tCKimlikNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn soyadiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dogumTarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cinsiyetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıseBaslamaTarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıstenAyrilmaTarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pozisyonIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn aktifMiDataGridViewCheckBoxColumn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label perDepartman;
    }
}

