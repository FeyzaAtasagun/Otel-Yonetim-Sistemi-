using System;
using System.Drawing;
using System.Windows.Forms;

namespace PersonelYonetimi
{
    public partial class FrmMaasHesaplama : Form
    {
        public FrmMaasHesaplama()
        {
            InitializeComponent();
        }

        private void FrmMaasHesaplama_Load(object sender, EventArgs e)
        {
            // Form yüklendiğinde çalışacak kodlar
            cmbPersonel.Items.AddRange(new string[] { "Örnek Personel 1", "Örnek Personel 2", "Örnek Personel 3" });
            // Personel listesini veritabanından çekebilirsiniz
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            // Maaş hesaplama işlemleri
            try
            {
                decimal toplamMaas = 0;
                decimal gunlukUcret = 0;
                
                if (decimal.TryParse(txtAylikBrutMaas.Text, out decimal brutMaas))
                {
                    gunlukUcret = brutMaas / 30; // Aylık 30 gün varsayımı
                    
                    int geldigiGunSayisi = Convert.ToInt32(txtGeldigiGunSayisi.Text);
                    int izinliGunSayisi = Convert.ToInt32(txtIzinliGunSayisi.Text);
                    int eksikMesai = Convert.ToInt32(txtEksikMesai.Text);
                    decimal ekMesaiSaat = Convert.ToDecimal(txtEkMesaiSaat.Text);
                    
                    decimal eksikMesaiUcreti = eksikMesai * (gunlukUcret / 8); // 8 saatlik mesai varsayımı
                    decimal ekMesaiUcreti = ekMesaiSaat * (gunlukUcret / 8) * 1.5m; // Ek mesai 1.5 kat ücret
                    
                    toplamMaas = brutMaas - eksikMesaiUcreti + ekMesaiUcreti;
                    
                    // Sonuçları göster
                    lblEksikMesaiTutar.Text = eksikMesaiUcreti.ToString("C2");
                    lblEkMesaiTutar.Text = ekMesaiUcreti.ToString("C2");
                    lblToplamMaas.Text = toplamMaas.ToString("C2");
                }
                else
                {
                    MessageBox.Show("Lütfen geçerli bir brüt maaş girin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hesaplama sırasında bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            // Form temizleme işlemleri
            txtAylikBrutMaas.Clear();
            txtGeldigiGunSayisi.Text = "30";
            txtIzinliGunSayisi.Text = "0";
            txtEksikMesai.Text = "0";
            txtEkMesaiSaat.Text = "0";
            lblEksikMesaiTutar.Text = "0 TL";
            lblEkMesaiTutar.Text = "0 TL";
            lblToplamMaas.Text = "0 TL";
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            // Maaş bilgilerini kaydetme işlemleri
            MessageBox.Show("Maaş bilgileri başarıyla kaydedildi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
